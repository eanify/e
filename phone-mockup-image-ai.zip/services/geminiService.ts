import { GoogleGenAI, Modality } from '@google/genai';
import type { MockupOptions } from '../types';

/**
 * Converts a File object to a base64 encoded string, without the data URL prefix.
 * @param file The file to convert.
 * @returns A promise that resolves with the base64 string.
 */
const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // remove the `data:image/jpeg;base64,` part
      const base64String = result.split(',')[1];
      resolve(base64String);
    };
    reader.onerror = (error) => reject(error);
  });

/**
 * Generates a phone mockup image using the Gemini API.
 * @param options The user-selected options for the mockup.
 * @returns A promise that resolves with a data URL for the generated image.
 */
export const generateMockupImage = async (options: MockupOptions): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error('API key is not configured. Please set the API_KEY environment variable.');
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  if (!options.image) {
    throw new Error('Image file is required.');
  }

  const base64Image = await fileToBase64(options.image);

  const prompt = `Create a high-quality, visually stunning phone mockup image.

  **Instructions:**
  1.  **Phone Model:** Use a model that looks exactly like a ${options.phoneModel}.
  2.  **Screen Content:** The provided image MUST be placed on the phone's screen. It should fit perfectly, without distortion.
  3.  **Overall Style:** The entire scene should have a "${options.style}" aesthetic. This includes the background, lighting, and the phone itself.
  ${options.text ? `4. **Custom Text:** Include the following text creatively within the mockup scene: "${options.text}". It should be legible and well-integrated, perhaps on a surface next to the phone or as a subtle title.` : ''}
  5.  **Output:** The result must be a single, clean, high-resolution image of the phone mockup. Do not output any text response, only the image.
  `;
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image,
            mimeType: options.image.type,
          },
        },
        { text: prompt },
      ],
    },
    config: {
        responseModalities: [Modality.IMAGE],
    },
  });
  
  const firstPart = response.candidates?.[0]?.content?.parts?.[0];

  if (firstPart && 'inlineData' in firstPart && firstPart.inlineData) {
    const { data, mimeType } = firstPart.inlineData;
    return `data:${mimeType};base64,${data}`;
  }

  throw new Error('AI failed to generate an image. Please try again with a different prompt or image.');
};
