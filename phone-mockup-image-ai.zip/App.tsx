import React, { useState, useCallback } from 'react';
import { GoogleGenAI } from '@google/genai';
import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import OptionSelector from './components/OptionSelector';
import TextInput from './components/TextInput';
import ActionButton from './components/ActionButton';
import LoadingSpinner from './components/LoadingSpinner';
import ResultDisplay from './components/ResultDisplay';
import { STYLES, PHONE_MODELS } from './constants';
import { generateMockupImage } from './services/geminiService';
import type { MockupOptions } from './types';

type AppStep = 'form' | 'loading' | 'result' | 'error';

export default function App() {
  const [step, setStep] = useState<AppStep>('form');
  const [uploadedImage, setUploadedImage] = useState<File | null>(null);
  const [selectedStyle, setSelectedStyle] = useState<string>(STYLES[0]);
  const [customText, setCustomText] = useState<string>('');
  const [selectedPhone, setSelectedPhone] = useState<string>(PHONE_MODELS[0]);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');

  const resetForm = useCallback(() => {
    setStep('form');
    setUploadedImage(null);
    setSelectedStyle(STYLES[0]);
    setCustomText('');
    setSelectedPhone(PHONE_MODELS[0]);
    setGeneratedImageUrl(null);
    setErrorMessage('');
  }, []);

  const handleGenerate = useCallback(async () => {
    if (!uploadedImage) {
      setErrorMessage('Don Allah a ɗora hoto kafin a ci gaba.');
      setStep('error');
      return;
    }

    setStep('loading');
    setErrorMessage('');

    const options: MockupOptions = {
      image: uploadedImage,
      style: selectedStyle,
      text: customText,
      phoneModel: selectedPhone,
    };

    try {
      const imageUrl = await generateMockupImage(options);
      setGeneratedImageUrl(imageUrl);
      setStep('result');
    } catch (error) {
      console.error(error);
      const message = error instanceof Error ? error.message : 'An samu kuskuren da ba a sani ba.';
      setErrorMessage(`An samu kuskure: ${message}`);
      setStep('error');
    }
  }, [uploadedImage, selectedStyle, customText, selectedPhone]);

  const renderContent = () => {
    switch (step) {
      case 'loading':
        return <LoadingSpinner />;
      case 'result':
        return (
          <ResultDisplay
            imageUrl={generatedImageUrl!}
            onRegenerate={handleGenerate}
            onStartNew={resetForm}
          />
        );
      case 'error':
        return (
          <div className="text-center p-8 bg-red-900/50 rounded-lg">
            <h2 className="text-2xl font-bold text-red-400 mb-4">Kuskure</h2>
            <p className="text-red-300 mb-6">{errorMessage}</p>
            <ActionButton text="Koma Baya" onClick={resetForm} />
          </div>
        );
      case 'form':
      default:
        return (
          <div className="w-full max-w-4xl mx-auto bg-gray-800/50 backdrop-blur-sm p-6 md:p-8 rounded-2xl shadow-2xl border border-gray-700">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex flex-col gap-6">
                <ImageUploader onImageUpload={setUploadedImage} />
                <OptionSelector
                  label="Zaɓi Style"
                  options={STYLES}
                  value={selectedStyle}
                  onChange={setSelectedStyle}
                />
              </div>
              <div className="flex flex-col gap-6">
                <TextInput
                  label="Rubuta Rubutu (ZABI)"
                  value={customText}
                  onChange={setCustomText}
                />
                <OptionSelector
                  label="Zaɓi Nau'in Waya"
                  options={PHONE_MODELS}
                  value={selectedPhone}
                  onChange={setSelectedPhone}
                />
              </div>
            </div>
            <div className="mt-8 pt-6 border-t border-gray-700">
              <ActionButton
                text="Ƙirƙiri"
                onClick={handleGenerate}
                disabled={!uploadedImage}
              />
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900/30 to-gray-900 font-sans p-4 md:p-8">
      <Header />
      <main className="flex flex-col items-center justify-center py-10">
        {renderContent()}
      </main>
    </div>
  );
}
