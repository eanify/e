export const STYLES: string[] = [
  "Minimalist",
  "Photorealistic",
  "Cartoon",
  "Flat Design",
  "Glassmorphism",
  "Dramatic Shadow",
  "Gradient Aura",
  "Classic Frame",
  "Studio Lighting",
  "Cyberpunk Neon",
  "Vintage Look",
];

export const PHONE_MODELS: string[] = [
  "iPhone 15 Pro",
  "iPhone 14",
  "Samsung Galaxy S24 Ultra",
  "Samsung Galaxy A55",
  "Google Pixel 8 Pro",
  "Tecno Camon 30",
  "Infinix Zero 30",
  "Huawei P60 Pro",
  "Itel S24",
  "Generic Modern Smartphone",
];
