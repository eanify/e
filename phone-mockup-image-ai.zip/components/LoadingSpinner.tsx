import React from 'react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8 bg-gray-800/50 backdrop-blur-sm rounded-2xl shadow-2xl">
      <div className="relative h-20 w-20">
        <div className="absolute inset-0 border-4 border-purple-500 rounded-full animate-spin"></div>
        <div className="absolute inset-0 border-4 border-pink-500 rounded-full animate-ping opacity-75"></div>
      </div>
      <p className="mt-6 text-xl font-semibold text-gray-300 tracking-wider">
        Ana ƙirƙira — don Allah jira...
      </p>
    </div>
  );
};

export default LoadingSpinner;
