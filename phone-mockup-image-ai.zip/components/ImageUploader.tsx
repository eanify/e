import React, { useState, useCallback, useMemo } from 'react';

interface ImageUploaderProps {
  onImageUpload: (file: File | null) => void;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload }) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && (file.type === 'image/png' || file.type === 'image/jpeg')) {
      onImageUpload(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      onImageUpload(null);
      setPreviewUrl(null);
    }
  }, [onImageUpload]);

  const dropzoneContent = useMemo(() => {
    if (previewUrl) {
      return (
        <img src={previewUrl} alt="Preview" className="w-full h-full object-contain rounded-lg" />
      );
    }
    return (
      <div className="text-center text-gray-400 flex flex-col items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
        </svg>
        <span className="font-semibold">Ɗora Hoto</span>
        <p className="text-xs mt-1">Jawo hoto anan ko danna don zaɓa</p>
        <p className="text-xs text-gray-500 mt-1">PNG, JPG</p>
      </div>
    );
  }, [previewUrl]);

  return (
    <div className="flex flex-col gap-2 h-full">
      <label className="font-semibold text-gray-300">Hoton Allon Waya</label>
      <div className="relative flex-grow min-h-[200px] border-2 border-dashed border-gray-600 rounded-lg p-4 hover:border-purple-500 transition-colors duration-300 flex items-center justify-center bg-gray-900/50">
        {dropzoneContent}
        <input
          type="file"
          accept="image/png, image/jpeg"
          onChange={handleFileChange}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
      </div>
    </div>
  );
};

export default ImageUploader;
