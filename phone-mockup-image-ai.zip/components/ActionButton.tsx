import React from 'react';

interface ActionButtonProps {
  text: string;
  onClick: () => void;
  disabled?: boolean;
  variant?: 'primary' | 'secondary';
}

const ActionButton: React.FC<ActionButtonProps> = ({ text, onClick, disabled = false, variant = 'primary' }) => {
  const baseClasses = "w-full text-center text-lg font-bold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 focus:outline-none focus:ring-4";
  
  const variantClasses = {
    primary: "bg-purple-600 hover:bg-purple-700 text-white focus:ring-purple-500/50 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:hover:bg-gray-600",
    secondary: "bg-gray-600 hover:bg-gray-700 text-white focus:ring-gray-500/50"
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseClasses} ${variantClasses[variant]}`}
    >
      {text}
    </button>
  );
};

export default ActionButton;
