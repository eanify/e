import React from 'react';
import ActionButton from './ActionButton';

interface ResultDisplayProps {
  imageUrl: string;
  onRegenerate: () => void;
  onStartNew: () => void;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ imageUrl, onRegenerate, onStartNew }) => {
  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col items-center gap-8 bg-gray-800/50 backdrop-blur-sm p-6 md:p-8 rounded-2xl shadow-2xl border border-gray-700">
      <h2 className="text-3xl font-bold text-center">Sakamako</h2>
      <div className="w-full aspect-square rounded-lg overflow-hidden bg-gray-900 shadow-inner">
        <img src={imageUrl} alt="Generated Mockup" className="w-full h-full object-contain" />
      </div>
      <div className="w-full flex flex-col sm:flex-row gap-4">
        <a 
          href={imageUrl} 
          download="phone-mockup.png"
          className="w-full text-center text-lg font-bold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 focus:outline-none focus:ring-4 bg-purple-600 hover:bg-purple-700 text-white focus:ring-purple-500/50"
        >
          Sauke Hoto
        </a>
        <ActionButton text="Sake Ƙirƙira" onClick={onRegenerate} variant="secondary" />
        <ActionButton text="Fara Sabo" onClick={onStartNew} variant="secondary" />
      </div>
    </div>
  );
};

export default ResultDisplay;
