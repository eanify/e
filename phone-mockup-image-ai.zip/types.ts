export interface MockupOptions {
  image: File;
  style: string;
  text: string;
  phoneModel: string;
}
